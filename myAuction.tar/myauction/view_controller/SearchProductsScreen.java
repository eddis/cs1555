package myauction.view_controller;

import java.awt.Point;
import java.sql.*;
import myauction.CLIObject;
import myauction.Session;

public class SearchProductsScreen extends Screen {
	public SearchProductsScreen(Session session) {
		super(session);
	}

	public int run() {
		return 0;
	}
}