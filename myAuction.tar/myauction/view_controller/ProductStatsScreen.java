package myauction.view_controller;

import java.awt.Point;
import java.sql.*;
import myauction.CLIObject;
import myauction.Session;

public class ProductStatsScreen extends Screen {
    public ProductStatsScreen(Session session) {
        super(session);
    }

    public int run() {
        return 0;
    }
}