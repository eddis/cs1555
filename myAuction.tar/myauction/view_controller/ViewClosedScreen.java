package myauction.view_controller;

import java.awt.Point;
import java.sql.*;
import myauction.CLIObject;
import myauction.Session;

public class ViewClosedScreen extends Screen {
	public ViewClosedScreen(Session session) {
		super(session);
	}

	public int run() {
		return 0;
	}
}